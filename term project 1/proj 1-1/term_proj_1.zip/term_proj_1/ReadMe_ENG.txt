﻿========================================================================
    Console Application: team_proj_1 Project Overview
========================================================================

It was created by modifying the TestCxImage project solution file provided as a template.

This file contains one file for each file that makes up the team_proj_1 application:
A summary description is included.

/////////////////////////////////////////////////////////////////////////////
How to run the program:
    Open the project as a .sln file and run the program using the F5 shortcut key.
    The result is saved as 'squid_game.jpg' in the folder where the source files are located.

/////////////////////////////////////////////////////////////////////////////
team_proj_1.vcproj
    This is the default project file for VC++ projects created using the AppWizard.
    Contains information about the version of Visual C++ that created the file and about the platform,
    configuration, and project features selected using the Application Wizard.

main.cpp
    This is the main application source file.
    The flow sequence presented in the assignment is reflected and executed through the following procedures.
    - Sample Image Load
    - add squid_head and squid_body
    - sub squid_points from the result
    - save the result

/////////////////////////////////////////////////////////////////////////////
SampleIMG Folder:
    This is a folder that stores sample images to be used for code execution.
    'squid_head', 'squid_body', and 'squid_points' provided as samples of the assignment are saved.

    If the names of the files are changed or the format (jpg, png, etc.) is changed,
    the macro declared in the stdafx.cpp file must also be changed.
	#define SAMPLE_SQUID_HEAD "./SampleIMG/squid_head.jpg"
	#define SAMPLE_SQUID_BODY "./SampleIMG/squid_body.jpg"
	#define SAMPLE_SQUID_POINTS "./SampleIMG/squid_points.jpg"
	#define SAMPLE_FORMAT_TYPE CXIMAGE_FORMAT_JPG

/////////////////////////////////////////////////////////////////////////////
Other standard files:

StdAfx.h, StdAfx.cpp
    This file is used to build the precompiled header (PCH) file TestCxImage.pch
    and the precompiled format (PCT) file StdAfx.obj.

    As mentioned earlier in the SampleIMG folder,
    if the name of the file to be used is changed or the format is changed,
    the macro in stdafx.cpp must be changed.
	#define SAMPLE_SQUID_HEAD "./SampleIMG/squid_head.jpg"
	#define SAMPLE_SQUID_BODY "./SampleIMG/squid_body.jpg"
	#define SAMPLE_SQUID_POINTS "./SampleIMG/squid_points.jpg"
	#define SAMPLE_FORMAT_TYPE CXIMAGE_FORMAT_JPG

    It is also a file that implements necessary functions to simplify the main function.
	void PrintSteps(int step);
	bool ImageLoad(CxImage* s_arr);
	bool EdgeDetection(CxImage* res, CxImage img);
	bool Squid_Combining(CxImage* res, CxImage first, CxImage second);
	bool Squid_Composite(CxImage* res, CxImage first, CxImage second);
