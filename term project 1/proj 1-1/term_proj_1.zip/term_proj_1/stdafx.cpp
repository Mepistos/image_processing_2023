// stdafx.cpp : ǥ�� ���� ���ϸ� ��� �ִ� �ҽ� �����Դϴ�.
// TestCxImage.pch�� �̸� �����ϵ� ����� �˴ϴ�.
// stdafx.obj���� �̸� �����ϵ� ���� ������ ���Ե˴ϴ�.

#include "stdafx.h"

// TODO: �ʿ��� �߰� �����
// �� ������ �ƴ� STDAFX.H���� �����մϴ�.

// TODO: ���α׷��� �ʿ��� �߰� �Լ��� ����

void PrintSteps(int step)
{
	printf("\n\n===================================\n");
	printf("step %d ", step);
	switch (step) {
	case 0:
		printf("Variables Def & Init");
		break;
	case 1:
		printf("Image load");
		break;
	case 2:
		printf("Edge detection");
		break;
	case 3:
		printf("Combining Head and Body");
		break;
	case 4:
		printf("Compoite Points");
		break;
	case 5:
		printf("Save result image");
		break;
	}
	printf("\n===================================\n");
}


#define SAMPLE_SQUID_HEAD "./SampleIMG/squid_head.jpg"
#define SAMPLE_SQUID_BODY "./SampleIMG/squid_body.jpg"
#define SAMPLE_SQUID_POINTS "./SampleIMG/squid_points.jpg"
#define SAMPLE_FORMAT_TYPE CXIMAGE_FORMAT_JPG
bool ImageLoad(CxImage* s_arr)
{
	bool ret = TRUE;
	s_arr[0].Load(_T(SAMPLE_SQUID_HEAD), SAMPLE_FORMAT_TYPE);
	s_arr[1].Load(_T(SAMPLE_SQUID_BODY), SAMPLE_FORMAT_TYPE);
	s_arr[2].Load(_T(SAMPLE_SQUID_POINTS), SAMPLE_FORMAT_TYPE);

	if (s_arr[0].IsValid()) printf("head success\n");
	else ret = FALSE;
	if (s_arr[1].IsValid()) printf("body success\n");
	else ret = FALSE;
	if (s_arr[2].IsValid()) printf("points success\n");
	else ret = FALSE;

	return ret;
}


bool EdgeDetection(CxImage* res, CxImage img)
{
	bool ret = TRUE;

	DWORD width = img.GetWidth();
	DWORD height = img.GetHeight();
	RGBQUAD color, ret_color;

	for (DWORD y = 0; y < height; y++) {
		for (DWORD x = 0; x < width; x++) {
			color = img.GetPixelColor(x, y);

		}
	}

	return ret;
}


#define THR 50				// threshold value
#define THRBG 10			// threshold value for BGcolor
#define BRIGHT 50			// brightness value

bool THR_BG(RGBQUAD bg, RGBQUAD color) {
	bool ret = TRUE;

	if (bg.rgbRed - THRBG <= color.rgbRed && color.rgbRed <= bg.rgbRed + THRBG)	ret = TRUE;
	else return FALSE;
	if (bg.rgbGreen - THRBG <= color.rgbGreen && color.rgbGreen <= bg.rgbGreen + THRBG)	ret = TRUE;
	else return FALSE;
	if (bg.rgbBlue - THRBG <= color.rgbBlue && color.rgbBlue <= bg.rgbBlue + THRBG)	ret = TRUE;
	else return FALSE;

	return ret;
}

bool Squid_Combining(CxImage* res, CxImage first, CxImage second)
{
	bool ret = TRUE;

	DWORD width = first.GetWidth();
	DWORD height = first.GetHeight();
	RGBQUAD first_color, second_color, res_color;
	RGBQUAD bgcolor;

	bgcolor.rgbRed = first.GetPixelColor(0, 0).rgbRed;
	bgcolor.rgbGreen = first.GetPixelColor(0, 0).rgbGreen;
	bgcolor.rgbBlue = first.GetPixelColor(0, 0).rgbBlue;

	for (DWORD y = 0; y < height; y++) {
		for (DWORD x = 0; x < width; x++) {
			int red = 0, green = 0, blue = 0;
			first_color = first.GetPixelColor(x, y);
			second_color = second.GetPixelColor(x, y);

			if (THR_BG(bgcolor, first_color)) {
				red = second_color.rgbRed;
				green = second_color.rgbGreen;
				blue = second_color.rgbBlue;
			}
			else if (THR_BG(bgcolor, second_color)) {
				red = first_color.rgbRed;
				green = first_color.rgbGreen;
				blue = first_color.rgbBlue;
			}
			else {
				red = first_color.rgbRed + second_color.rgbRed;
				green = first_color.rgbGreen + second_color.rgbGreen;
				blue = first_color.rgbBlue + second_color.rgbBlue;
			}

			red = (red > 255) ? 255 : ((red > 0) ? red : 0);
			green = (green > 255) ? 255 : ((green > 0) ? green : 0);
			blue = (blue > 255) ? 255 : ((blue > 0) ? blue : 0);

			res_color.rgbRed = (BYTE)(red);
			res_color.rgbGreen = (BYTE)(green);
			res_color.rgbBlue = (BYTE)(blue);

			res->SetPixelColor(x, y, res_color);
		}
	}

	return ret;
}

bool Squid_Composite(CxImage* res, CxImage first, CxImage second)
{
	bool ret = TRUE;

	DWORD width = first.GetWidth();
	DWORD height = first.GetHeight();
	RGBQUAD first_color, second_color, res_color;
	RGBQUAD bgcolor;

	bgcolor.rgbRed = first.GetPixelColor(0, 0).rgbRed;
	bgcolor.rgbGreen = first.GetPixelColor(0, 0).rgbGreen;
	bgcolor.rgbBlue = first.GetPixelColor(0, 0).rgbBlue;

	for (DWORD y = 0; y < height; y++) {
		for (DWORD x = 0; x < width; x++) {
			int red = 0, green = 0, blue = 0;
			first_color = first.GetPixelColor(x, y);
			second_color = second.GetPixelColor(x, y);

			if (second_color.rgbRed > THR || second_color.rgbGreen > THR || second_color.rgbBlue > THR) {
				red = bgcolor.rgbRed;
				green = bgcolor.rgbGreen;
				blue = bgcolor.rgbBlue;
			}
			else {
				red = first_color.rgbRed;
				green = first_color.rgbGreen;
				blue = first_color.rgbBlue;
			}

			red = (red > 255) ? 255 : ((red > 0) ? red : 0);
			green = (green > 255) ? 255 : ((green > 0) ? green : 0);
			blue = (blue > 255) ? 255 : ((blue > 0) ? blue : 0);

			res_color.rgbRed = (BYTE)(red);
			res_color.rgbGreen = (BYTE)(green);
			res_color.rgbBlue = (BYTE)(blue);

			res->SetPixelColor(x, y, res_color);
		}
	}

	return ret;
}