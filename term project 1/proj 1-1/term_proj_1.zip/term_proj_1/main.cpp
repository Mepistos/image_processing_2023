// TestCxImage.cpp : �ܼ� ���� ���α׷��� ���� �������� �����մϴ�.
//

#include "stdafx.h"

int _tmain(int argc, _TCHAR* argv[])
{
	/*
	Sample code
	*/
	/*
	CxImage  image;
	// bmp -> jpg

	image.Load(_T("image.bmp"), CXIMAGE_FORMAT_BMP);
	if (image.IsValid()){
		if(!image.IsGrayScale()) image.IncreaseBpp(24);
		image.SetJpegQuality(80);
		image.Save(_T("image.jpg"),CXIMAGE_FORMAT_JPG);

		printf("image.bmp load success\n");
	}
	/*/

	// def. variables & init
	PrintSteps(0);
	CxImage img_samples[3];	// 0: head, 1: body, 2: points

	// img load
	PrintSteps(1);
	if (!ImageLoad(img_samples)) {
		printf("Loading Failed\n");
		return -1;
	}

	/*
	// each image's edge detection
	PrintSteps(2);
	for (int i = 0; i < 3; i++) {
		if (!EdgeDetection(&img_samples[i], img_samples[i])) {
			printf("EdgeDetection Failed\n");
			return -1;
		}
		else {
			printf("%d Success\n", i+1);
		}
	}
	*/
	
	// combine head and body
	PrintSteps(3);
	if (!Squid_Combining(&img_samples[0], img_samples[0], img_samples[1])) {
		printf("Combining Failed\n");
		return -1;
	}
	else {
		printf("Combining Success\n");
		img_samples[0].Save(_T("./squid_game_combine.jpg"), CXIMAGE_FORMAT_JPG);
	}

	// composite points
	PrintSteps(4);
	if (!Squid_Composite(&img_samples[0], img_samples[0], img_samples[2])) {
		printf("Composite Failed\n");
		return -1;
	}
	else {
		printf("Composite Success\n");
		img_samples[0].Save(_T("./squid_game_composite.jpg"), CXIMAGE_FORMAT_JPG);
	}

	// save result image
	PrintSteps(5);
	if (img_samples[0].IsValid()) img_samples[0].Save(_T("./squid_game.jpg"), CXIMAGE_FORMAT_JPG);
	else printf("result image is not Valid\n");

	return 0;
}

