﻿========================================================================
    콘솔 응용 프로그램 : team_proj_1 프로젝트 개요
========================================================================

Template으로 제공된 TestCxImage 프로젝트 솔루션 파일을 수정하여 만들었습니다.

이 파일에는 team_proj_1 응용 프로그램을  구성하는 각 파일에 대한
요약 설명이 포함되어 있습니다.

/////////////////////////////////////////////////////////////////////////////
프로그램 실행 방법:
    .sln 파일로 프로젝트를 열어주고, F5 단축키를 통해 프로그램을 실행시키면 된다.
      결과물은 소스파일들이 위치한 폴더에 'squid_game.jpg'라는 이름으로 저장된다.

/////////////////////////////////////////////////////////////////////////////
team_proj_1.vcproj
    응용 프로그램 마법사를 사용하여 생성한 VC++ 프로젝트의 기본 프로젝트 파일입니다.
    파일을 생성한 Visual C++ 버전에 대한 정보와
    응용 프로그램 마법사를 사용하여 선택한 플랫폼, 구성 및 프로젝트 기능에 대한
    정보가 들어 있습니다.

main.cpp
    기본 응용 프로그램 소스 파일입니다.
    과제에서 제시한 Flow Sequence가 반영되어 다음과 같은 절차로 실행됩니다.
    - Sample Image Load
    - add squid_head and squid_body
    - sub squid_points from the result
    - save the result

/////////////////////////////////////////////////////////////////////////////
SampleIMG 폴더:
    코드 실행에 사용될 샘플이미지를 저장하는 폴더입니다.
    과제의 샘플로 제공된 'squid_head', 'squid_body', 'squid_points'가 저장되어 있습니다.

    해당 파일들의 이름을 변경하거나, Format(jpg, png, etc.)이 변경되는 경우,
      stdafx.cpp 파일에 선언된 매크로도 변경해주어야 합니다.
	#define SAMPLE_SQUID_HEAD "./SampleIMG/squid_head.jpg"
	#define SAMPLE_SQUID_BODY "./SampleIMG/squid_body.jpg"
	#define SAMPLE_SQUID_POINTS "./SampleIMG/squid_points.jpg"
	#define SAMPLE_FORMAT_TYPE CXIMAGE_FORMAT_JPG

/////////////////////////////////////////////////////////////////////////////
기타 표준 파일:

StdAfx.h, StdAfx.cpp
    이 파일은 미리 컴파일된 헤더(PCH) 파일인 TestCxImage.pch와
    미리 컴파일된 형식(PCT) 파일인 StdAfx.obj를 빌드하는 데 사용됩니다.

    앞서 SampleIMG 폴더에서 언급한 것 처럼,
    사용할 파일의 이름이 변경되거나, Format을 변경할 경우, stdafx.cpp의 매크로를 변경해 주어야 합니다.
	#define SAMPLE_SQUID_HEAD "./SampleIMG/squid_head.jpg"
	#define SAMPLE_SQUID_BODY "./SampleIMG/squid_body.jpg"
	#define SAMPLE_SQUID_POINTS "./SampleIMG/squid_points.jpg"
	#define SAMPLE_FORMAT_TYPE CXIMAGE_FORMAT_JPG

    main 함수의 간소화를 위해, 필요한 기능들을 구현한 파일이기도 합니다.
	void PrintSteps(int step);
	bool ImageLoad(CxImage* s_arr);
	bool EdgeDetection(CxImage* res, CxImage img);
	bool Squid_Combining(CxImage* res, CxImage first, CxImage second);
	bool Squid_Composite(CxImage* res, CxImage first, CxImage second);
